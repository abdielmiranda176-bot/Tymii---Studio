TYMII STUDIO WEBSITE
1. Upload index.html and tymii-runway.png together to the ROOT of your GitHub repository.
2. GitHub repository -> Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
3. Wait for GitHub Pages to publish.
4. Replace the Discord button URL in index.html with your own profile/server invite before publishing.
The portfolio images are concept visuals, not real client projects.
